Prime Factorization Tool by Balping
	for CASIO PRIZM calculators
	by balping@cemetech.net
	email: balping.official@gmail.com
	copyright balping 2013
	original package downloadable at http://www.cemetech.net/programs/index.php?mode=folder&path=/prizm/math/

This is a prime factorization tool for Casio calculators written in BASIC

Usage
	Enter the number (must be a positive integer) that you want to factorize
	Press [EXE]
	The output is displayed as a matrix
	Press [EXE] to input another number
	Or press 0 and [EXE] to exit the program

Limitations
	The algorithm is very simple and the calculation can take a lot of time if you enter large numbers

Example
	Number? 6776
	Output: 2^3 * 7^1 * 11^2
		+---+---+
		| 0 | 0 | -> ignore this row
		+---+---+
		| 2 | 3 | -> this means: 2^3
		+---+---+
		| 7 | 1 | -> 7^1
		+---+---+
		| 11| 2 | -> 11^2
		+---+---+
