15-puzzle
	for CASIO PRIZM calculators
	version: 1.00
	Developed by balping@cemetech.net
	e-mail: balping.official@gmail.com
	© balping 2013
	original package downloadable at http://www.cemetech.net/programs/index.php?mode=folder&path=/prizm/games/

The 15-puzzle (also called Gem Puzzle, Boss Puzzle, Game of Fifteen, Mystic Square and many others) is a sliding puzzle that consists of a frame of numbered square tiles in random order with one tile missing.

Controls
	Use the arrow keys to move a piece.
	Press the [EXIT] key if you would like to close a message box.
	Press [F1] to shuffle the puzzle. It makes 1000 random moves by default. Your moves are counted after the shuffle.
	Press [F2] to reset the puzzle.
	Press [F3] to display the help.
