## Changelog

### Version 1.1.1:
- Fade in the header text after it is set
- Remove the padding from the content view because it caused a weird coloring effect

### Version 1.1.0:
- Add an 'Inbox' style expansion animation to the window

### Version 1.0.1:
- Fix issue with the expansion when there is no header
- Allow for keyboard showing on Sliding Activities

### Version 1.0.0:
- Initial release and feature set
