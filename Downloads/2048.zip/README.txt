2048
	for CASIO PRIZM calculators
	version: 1.00
	Developed by balping@cemetech.net
	e-mail: balping.official@gmail.com
	Original game and design by Gabriele Cirulli http://git.io/2048
	© balping 2014
	original package downloadable at http://tiny.cc/8hjfex
	help and support: via e-mail (balping.official@gmail.com) or at Cemetech forum: http://www.cemetech.net/forum/viewtopic.php?p=217605

This is a port of the popular browser and mobile game. Use your arrow keys to move the tiles. When two tiles with the same number touch, they merge into one!

Files
	This game saves one file to the main memory. You can find it in Memory Manager / Main Memory / @2048/ GAME
	This file contains your current gameplay and your highscore. If you delete it, you won't be able to continue your paused game and your highscore will be reset.

Bugs
	Please note that this is the first release of this program. Please send bug reports to my e-mail address (balping.official@gmail.com) or post it at the forum thread at Chemetech.
